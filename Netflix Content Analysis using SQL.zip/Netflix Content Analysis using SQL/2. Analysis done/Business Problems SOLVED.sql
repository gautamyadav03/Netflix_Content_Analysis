-- Solutions to queries
use netflix_database;

-- 1. Count the number of Movies vs TV Shows
select sum(case when type = "movie" then 1 else 0 end) as 'Number of Movies',
	   sum(case when type = "tv show" then 1 else 0 end) as 'Number of TV Shows'
from netflix;       


-- 2. Find the most common rating for movies and TV shows
select rating as 'Most Common Rating'
from netflix
group by rating
order by count(rating) desc
limit 1;


-- 3. List all movies released in a specific year (e.g., 2020)
select title as 'Movies'
from netflix
where release_year = 2020;


-- 4. Find the top 5 countries with the most content on Netflix
select country          
from(
select country
from netflix
group by country
order by count(*) desc) t
where country is not null
limit 5;


-- 5. Identify the longest movie
select title as 'Movie',duration as 'Duration'
from netflix
where type = "movie" and 
	cast(trim(replace(duration," min","")) as unsigned) = 
    (select max(cast(trim(replace(duration," min","")) as unsigned)) from netflix where type = "movie");


-- 6. Find content added in the last 5 years
select title as 'Content added in last 5 years'
from netflix
where release_year >= year(sysdate())-5;


-- 7. Find all the movies/TV shows by director 'Rajiv Chilaka'!
select title
from netflix
where director = "Rajiv Chilaka";


-- 8. List all TV shows with more than 5 seasons
select title as 'TV Shows',duration as Duration
from netflix
where type = "tv show" and cast(trim(replace(duration ," seasons","")) as unsigned) > 5;


-- 9. Count the number of content items in each genre
select listed_in as Genre,count(*) as 'NUmber of items'
from netflix
group by listed_in;


-- 10.Find each year and the average numbers of content release in India on netflix. 
--    return top 5 year with highest avg content release!
select release_year as 'Release Year',count(release_year) as 'Number of Content'
from netflix
where country = "India"
group by release_year
order by count(release_year) desc
limit 5;


-- 11. List all movies that are documentaries
select title
from netflix
where type = "movie" and listed_in like "%documentaries%";


-- 12. Find all content without a director
select title
from netflix
where director is null;


-- 13. Find how many movies actor 'Salman Khan' appeared in last 10 years!
select count(title) as 'Number of Movies'
from netflix
where type = "movie" and casts like "%Salman Khan%" and release_year > year(sysdate())-10;


-- 14. Find the top 10 actors who have appeared in the highest number of movies produced in India.
select casts
from netflix
where country = "india"
group by casts
order by count(casts) desc
limit 10;


-- 15. Categorize the content based on the presence of the keywords 'kill' and 'violence' in 
--     the description field. Label content containing these keywords as 'Bad' and all other 
-- 	content as 'Good'. Count how many items fall into each category.
select sum(case when description like "%kill%" or description like "%violence%" then 1 else 0 end) as 'Number of Bad content',
       sum(case when description like "%kill%" or description like "%violence%" then 0 else 1 end) as 'Number of Good content'
from netflix;

